## Banana Bread

<img src="https://images.unsplash.com/photo-1569762404472-026308ba6b64?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=634&q=80" alt="Banana Bread">

### Banana Bread Recipe
Preheat the oven to 350°F, and butter a 4x8-inch loaf pan. In a mixing bowl, mash the ripe bananas with a fork until completely smooth. Stir the melted butter into the mashed bananas. Mix in the baking soda and salt. Stir in the sugar, beaten egg and vanilla extract. Mix in the flour. Pour the batter into your prepared loaf pan. Bake for 50 minutes to 1 hour at 350°F, or until a tester inserted into the center comes out clean. Remove from oven and let cool in the pan for a few minutes. Then remove the banana bread from the pan and let cool completely before serving.

### Muzlu Kek Tarifi
Fırınınızı önceden 350°F’de ısıtın. 4x8-inch boyutlarında bir kek kalıbını tereyağı ile yağlayın. Muzları soyup karıştırma kabına aktarın ve tamamen pürüzsüz olana kadar bir çatalla ezin. Kabartma tozunu ve tuzu bir kapta karıştırın. Üzerine şekeri, çırpılmış yumurtayı ve vanilya özütünü ekleyin. Unu'da ekleyerek karıştırın. Hamuru hazırladığınız kek kalıbına dökün. Ortasına batırdığınız bir kürdan kuru çıkana kadar 350°F’de 50 - 60 dakika boyunca pişirin. Keki fırından alıp kalıbının içinde birkaç dakika boyunca soğumaya bırakın. Kalıbı ters çevirip keki çıkartın ve servis tabağına aktarın ve servis yapmadan önce tamamen soğumasını bekleyin.

Görsel: https://unsplash.com/s/photos/banana-bread
