# responsive-template

Projeyi çalıştırmak için;
`parcel serve ./development/index.njk`

## Tasarımlar
Figma: https://www.figma.com/file/YISG57EpMwQ9HF6eIcY0iT/Homework?node-id=0%3A1

Tasarımları inceleyebilmek için Figma ya ücretsiz kayıt olmanız gerekiyor....
